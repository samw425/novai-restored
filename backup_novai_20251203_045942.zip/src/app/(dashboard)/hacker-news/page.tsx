'use client';

import { HackerFeedContainer } from '@/components/feed/HackerFeedContainer';

export default function HackerNewsPage() {
    return <HackerFeedContainer />;
}
